///
/// @file	LocalLibrary.h 
/// @brief	Library header
///
/// @details	<#details#>
/// @n	
/// @n @b	Project PlainProtocol
/// @n @a	Developed with [embedXcode](http://embedXcode.weebly.com)
/// 
/// @author	qiao
/// @author	qiao
/// @date	13-4-2 上午9:17
/// @version	<#version#>
/// 
/// @copyright	© qiao, 2013年
/// @copyright	CC = BY NC SA
///
/// @see	ReadMe.txt for references
///


#ifndef ARDUINO
#define ARDUINO 103
#endif

// Core library - IDE-based
#if defined(MPIDE) // chipKIT specific
#include "WProgram.h"
#elif defined(DIGISPARK) // Digispark specific
#include "Arduino.h"
#elif defined(ENERGIA) // LaunchPad, FraunchPad and StellarPad specific
#include "Energia.h"
#elif defined(MAPLE_IDE) // Maple specific
#include "WProgram.h"
#elif defined(CORE_TEENSY) // Teensy specific
#include "WProgram.h"
#elif defined(WIRING) // Wiring specific
#include "Wiring.h"
#elif defined(ARDUINO) && (ARDUINO >= 100) // Arduino 1.0x and 1.5x specific
#include "Arduino.h"
#elif defined(ARDUINO) && (ARDUINO < 100)  // Arduino 23 specific
#include "WProgram.h"
#endif // end IDE

#ifndef PlainProtocol_LocalLibrary_h
#define PlainProtocol_LocalLibrary_h


#define SerialTransceiver Serial
//#define SerialToDevice Serial1
#define MaxContentLenth  5
#define MaxCommandType   20


const char* const commandType[]={"speed","torque","Oracle","Adobe","Macromedia","Intel"};


class PlainProtocol {
private:
  boolean isNumber(String&  stringbuf);
  String frame;
//  char* commandType[MaxCommandType];
  void (*commandProcessType[sizeof(commandType)/sizeof(commandType[0])])(void);
  
public:
  
  String commandInput,commandOutput;
  int addressInput,addressOutput;
  int contentInput[MaxContentLenth],contentOutput[MaxContentLenth];
  int contentOutputLenth;
  boolean isAddressOutput;
  
  PlainProtocol();
  void init();
  void receiveFrame();
  void sendFrame();
  boolean parseFrame(String theFrame);
  void commandProcess();
  void addressOutputEnable();
  void addressOutputDisable();
  void createFrame(int address, String command, int lenth, ...);
  int commandIndex(String& command);
  void commandAttach(String command, void (*commandProcess)());
};




















#endif
