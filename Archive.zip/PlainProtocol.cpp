//
// LocalLibrary.cpp 
// Library C++ code
// ----------------------------------
// Developed with embedXcode 
// http://embedXcode.weebly.com
//
// Project PlainProtocol
//
// Created by qiao, 13-4-2 上午9:17
// qiao
//	
//
// Copyright © qiao, 2013年
// Licence CC = BY NC SA
//
// See LocalLibrary.cpp.h and ReadMe.txt for references
//


#include "PlainProtocol.h"
#include <stdarg.h>




PlainProtocol::PlainProtocol()
{
  frame="";
  commandInput="";
  commandOutput="";
  addressInput=0;
  addressOutput=0;
  contentOutputLenth=0;
  memset(contentInput, 0x00, sizeof(contentInput));
  memset(contentOutput, 0x00, sizeof(contentOutput));
  isAddressOutput=false;
}

void PlainProtocol::init()
{
  SerialTransceiver.begin(57600);
}


void PlainProtocol::createFrame(int address, String command, int lenth, ...)
{
  va_list pArguement;
  int *pContent;
  
  addressOutput=address;
  commandOutput=command;
  contentOutputLenth=lenth;
  
  va_start(pArguement, lenth);
  for (int i=0; i<lenth; i++) {
    contentOutput[i]=va_arg(pArguement, int);
  }
  va_end(pArguement);
}

int PlainProtocol::commandIndex(String &command)
{
  int i;
  for (i=0; i < (sizeof(commandType)/sizeof(commandType[0])); i++) {
    if (command==commandType[i]) {
      return i;
    }
  }
  return -1;
}

void PlainProtocol::sendFrame()
{
  int index;
  if (isAddressOutput) {
    SerialTransceiver.print('#');
    SerialTransceiver.print(addressOutput);
  }
  SerialTransceiver.print('<');
  SerialTransceiver.print(commandOutput);
  SerialTransceiver.print('>');
  if (contentOutputLenth!=0) {
    for (index=0; index<contentOutputLenth-1; index++) {
      SerialTransceiver.print(contentOutput[index]);
      SerialTransceiver.print(',');
    }
    SerialTransceiver.print(contentOutput[index]);
  }
  SerialTransceiver.print(';');
}

void PlainProtocol::addressOutputEnable()
{
  isAddressOutput=true;
}

void PlainProtocol::addressOutputDisable()
{
  isAddressOutput=false;
}


boolean PlainProtocol::commandAttach(String command, void (*commandProcess)(void))
{
  int index;
  if ((index=commandIndex(command)) == -1) {
    return false;
  }
  commandProcessType[index]=commandProcess;
  return true;
}


void PlainProtocol::commandProcess()
{
  (commandProcessType[commandIndex(commandInput)])();
}

void PlainProtocol::receiveFrame()
{
  int semicolonIndex;
  if (SerialTransceiver.available()) {
    while (SerialTransceiver.available()) {
      frame += (char)SerialTransceiver.read();
    }
    while ((semicolonIndex=frame.indexOf(';')) != -1) {
      if (parseFrame(frame.substring(0, semicolonIndex))==true) {
        
        commandProcess();
        
        Serial.print("addressInput: ");
        Serial.println(addressInput);
        Serial.print("commandIntput: ");
        Serial.println(commandInput);
        Serial.print("contentInput[0]: ");
        Serial.println(contentInput[0]);
        Serial.print("contentInput[1]: ");
        Serial.println(contentInput[1]);
        Serial.print("contentInput[2]: ");
        Serial.println(contentInput[2]);
        
      }
      else
        
      {
        Serial.println("wrong command");
      }

      frame=frame.substring(semicolonIndex+1);
    }
  }
}


boolean PlainProtocol::isNumber(String& stringBuf)
{
  int i;
  for (i=0; i<stringBuf.length(); i++) {
    if (stringBuf[i]<'0'||stringBuf[i]>'9') {
      return false;
    }
  }
  return true;
}


boolean PlainProtocol::parseFrame(String theFrame)
{
  Serial.println(theFrame);
  
  int commaIndex=theFrame.indexOf(',');
  int commaIndexLast;
  int leftAngleBracketIndex=theFrame.indexOf('<');
  int rightAngleBracketIndex=theFrame.indexOf('>');
  int poundSignIndex=theFrame.indexOf('#');
  int contentIndex=0;
  String stringBuf;
  
  if (leftAngleBracketIndex!=-1   &&
      rightAngleBracketIndex!=-1  &&
      (poundSignIndex==-1 || poundSignIndex<leftAngleBracketIndex)  &&
      leftAngleBracketIndex < rightAngleBracketIndex  &&
      (commaIndex==-1 || rightAngleBracketIndex < commaIndex)
      ) {
    
    commandInput=theFrame.substring(leftAngleBracketIndex+1, rightAngleBracketIndex);
    
    if (commaIndex==-1) {
      stringBuf=theFrame.substring(rightAngleBracketIndex+1);
      
      if (isNumber(stringBuf)) {
        contentInput[0]=stringBuf.toInt();
      }
      else{
        return false;
      }
      
      
    }
    else{
      
      stringBuf=theFrame.substring(rightAngleBracketIndex+1,commaIndex);
      if (isNumber(stringBuf)) {
        contentInput[contentIndex++]=stringBuf.toInt();
      }
      else{
        return false;
      }
      
      commaIndexLast=commaIndex;
      commaIndex=theFrame.indexOf(',',commaIndex+1);
      while (commaIndex!=-1) {
        
        stringBuf=theFrame.substring(commaIndexLast+1,commaIndex);
        if (isNumber(stringBuf)) {
          contentInput[contentIndex++]=stringBuf.toInt();
        }
        else{
          return false;
        }
        
        
        commaIndexLast=commaIndex;
        commaIndex=theFrame.indexOf(',',commaIndex+1);
      }
      stringBuf=theFrame.substring(commaIndexLast+1);
      
      if (isNumber(stringBuf)) {
        contentInput[contentIndex]=stringBuf.toInt();
      }
      else{
        return false;
      }
      
    }
    
    if (theFrame.indexOf('#')!=-1){
      addressInput=(theFrame.substring(theFrame.indexOf('#')+1, theFrame.indexOf('<'))).toInt();
    }
    else{
      //no addressInput
    }
    
  }
  else{
    return false;
  }
  return true;
}





